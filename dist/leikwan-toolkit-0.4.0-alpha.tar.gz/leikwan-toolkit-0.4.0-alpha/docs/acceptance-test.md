# 验收测试

本页用于 v0.4.0-alpha 收尾验收。

## 静态检查

```bash
bash -n leikwan-toolkit.sh scripts/package-release.sh scripts/check-redaction.sh scripts/bootstrap.sh
shellcheck leikwan-toolkit.sh scripts/package-release.sh scripts/check-redaction.sh scripts/bootstrap.sh
git diff --check
scripts/check-redaction.sh
scripts/package-release.sh
```

Release 包应生成：

```text
dist/leikwan-toolkit-0.4.0-alpha.tar.gz
```

包内包含：

```text
leikwan-toolkit.sh
scripts/bootstrap.sh
docs/
README.md
```

包内不包含独立卸载脚本或旧入口脚本。

## 命名

Banner 显示：

```text
Leikwan Toolkit
利群快速组网工具
Author : ike-sh
Version: 0.4.0-alpha
GitHub : https://github.com/ike-sh/leikwan-toolkit
```

安装命令使用：

```bash
curl -fsSL -o /tmp/lq-bootstrap.sh https://raw.githubusercontent.com/ike-sh/leikwan-toolkit/main/scripts/bootstrap.sh && bash /tmp/lq-bootstrap.sh && lq
```

唯一主脚本安装为 `/root/leikwan-toolkit.sh`，`lq` 和 `LQ` 都指向它。

卸载入口：

```text
lq -> 主菜单 -> 卸载全部
bash /root/leikwan-toolkit.sh --uninstall
```

## 快速组网菜单

必须显示第 7 项 PBR、第 8 项完整说明：

```text
2. 我现在在利群主机：生成 / 新增公网入口网络码
3. 我现在在公网入口：粘贴利群网络码，部署本机入口
4. 我现在在利群主机：粘贴公网入口返回码，完成接入
7. IPv4 多出口策略路由 / PBR
8. 查看完整分步说明
```

已有 `aliyun 10.198.1.2 tcp/8301` 时，B 再生成网络码，应推荐 `home` 或 `entry2`、`10.198.1.3`、`8302`。

如果已有 `/etc/leikwan-toolkit/easytier/network.env` 且角色是 `leikwan-relay`，再次生成网络码必须复用现有 network name / secret，不覆盖 `network.env`，不重启 `easytier-relay`，已有入口不掉线。

新 A 粘贴网络码部署时，默认使用 B 推荐的 `SUGGESTED_ENTRY_NAME`、`SUGGESTED_ENTRY_ET_IP`、`SUGGESTED_EASYTIER_PORT`。

新 A 若在“本机 EasyTier IP [10.198.1.3]”输入 `home.example.com`，应提示这是域名而不是 EasyTier 虚拟 IP，并提示 DDNS 应填在“本机公网 IP / 域名”；下一轮默认值仍是 `10.198.1.3`。

## 公网入口管理

B 侧路径：

```text
利群主机 -> 公网入口列表管理
```

删除、启用/禁用、修改权重、测试公网入口必须先展示列表，支持编号或名称，空输入返回。

B 粘贴新 A 返回的 ENTRY 入口码后，默认只保存 `entries.tsv`，不渲染 relay service，不重启 relay。用户选择稍后应用时，已有入口保持在线。用户选择立即应用时，必须再次提示重启 relay 会短暂中断所有入口；确认后才 restart，并测试所有 enabled entries。

立即应用后：

```text
entries.tsv 同时存在 aliyun 和 home
relay service peer 列表同时包含 aliyun 和 home
```

A 侧路径：

```text
主菜单 -> 公网入口
```

只保留本机功能：部署本机入口、配置本机入口端口池、查看本机公网入口状态。在 B 上误进状态页时，应 WARN 并引导到 B 侧入口列表管理。

## 转发目标

添加转发目标时：

- 公网入口端口提示显示端口池范围和推荐下一个未使用端口。
- 后端目标端口不显示默认值，空输入会 WARN。

修改、删除、启用/禁用、测试单个转发目标必须先展示列表，支持编号或名称。修改、删除、启用/禁用后必须重新生成 `resolved.tsv` 并应用 relay nftables。

域名目标示例：

```text
name=Hinet
entry_port=10002
target_host=tw.example.com
target_port=52936
```

列表应显示：

```text
Hinet 10002 -> tw.example.com(203.0.113.20):52936 eth1 - enabled
```

`apply-relay` 每次重新解析域名；IP 变化时输出解析变化并刷新 nftables。

## PBR

菜单：

```text
1. 添加静态 PBR
2. 从现有转发目标添加 PBR
3. 应用 PBR
4. 查看 PBR
```

静态 PBR 输入域名时，应提示改用“从现有转发目标添加 PBR”。从转发目标选择域名后端时，应解析当前 IP 并写入 `resolved_ip/32`，同时记录来源转发名和 `target_host`。

## 依赖和下载排错

A 缺少 `unzip` 且 apt 安装失败时，应明确提示 `unzip` 缺失，不应误报 EasyTier zip 坏包。脚本应跳过 zip 候选并优先尝试 `tar.gz` / `tgz`，或引导用户提供本地 EasyTier 包 / `easytier-core` / `easytier-cli`。

`doctor` 应检查：

```text
raw.githubusercontent.com / api.github.com / cn.archive.ubuntu.com 是否解析到 198.18.x.x fake-ip
curl / jq / tar / unzip 是否存在
apt 源更新是否失败或返回 403
```

## 旧名称检查

旧入口脚本文件名、独立卸载脚本文件名、旧仓库 URL、旧英文标题都不应命中主线内容。`leikwan-wg-toolkit` 只允许出现在旧路径迁移/清理说明里。
